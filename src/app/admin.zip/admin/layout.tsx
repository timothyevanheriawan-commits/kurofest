"use client";

import { createClient } from "@/lib/supabase";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { cn } from "@/lib/utils";
import {
    LayoutDashboard,
    Users,
    Calendar,
    Newspaper,
    LogOut,
    Menu,
    X,
    ShoppingBag
} from "lucide-react";
import { useState } from "react";

const ADMIN_NAV = [
    { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
    { label: "Guests", href: "/admin/guests", icon: Users },
    { label: "Orders", href: "/admin/orders", icon: ShoppingBag },
    { label: "Schedule", href: "/admin/schedule", icon: Calendar },
    { label: "News", href: "/admin/news", icon: Newspaper },
];

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const router = useRouter();
    const pathname = usePathname();
    const supabase = createClient();
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    const handleSignOut = async () => {
        await supabase.auth.signOut();
        router.push("/admin/login");
        router.refresh();
    };

    // If we're on the login page, don't show the layout
    if (pathname === "/admin/login") {
        return <>{children}</>;
    }

    return (
        <div className="min-h-screen bg-washi-100 flex text-sumi-950">
            {/* Mobile Menu Toggle */}
            <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="lg:hidden fixed bottom-6 right-6 z-50 w-14 h-14 bg-sumi-950 text-washi-100 flex items-center justify-center shadow-lg"
            >
                {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>

            {/* Sidebar */}
            <aside
                className={cn(
                    "fixed inset-y-0 left-0 z-40 w-64 bg-sumi-950 text-washi-100 transition-transform duration-300 transform border-r border-sumi-800",
                    isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
                )}
            >
                <div className="h-full flex flex-col p-6">
                    <Link href="/admin" className="flex items-center gap-3 mb-10 px-2">
                        <div className="w-8 h-8 border border-washi-100 flex items-center justify-center font-serif text-sm font-bold">
                            黒
                        </div>
                        <span className="font-display font-bold tracking-tight">ADMIN PANEL</span>
                    </Link>

                    <nav className="flex-1 space-y-1">
                        {ADMIN_NAV.map((item) => {
                            const isActive = pathname === item.href;
                            const Icon = item.icon;
                            return (
                                <Link
                                    key={item.href}
                                    href={item.href}
                                    onClick={() => setIsSidebarOpen(false)}
                                    className={cn(
                                        "flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors",
                                        isActive
                                            ? "bg-washi-100 text-sumi-950"
                                            : "text-washi-100/60 hover:text-washi-100 hover:bg-sumi-900"
                                    )}
                                >
                                    <Icon size={18} />
                                    {item.label}
                                </Link>
                            );
                        })}
                    </nav>

                    <button
                        onClick={handleSignOut}
                        className="mt-auto flex items-center gap-3 px-4 py-3 text-sm font-medium text-shu-400 hover:text-shu-300 hover:bg-sumi-900 transition-colors"
                    >
                        <LogOut size={18} />
                        Sign Out
                    </button>
                </div>
            </aside>

            {/* Overlay for mobile sidebar */}
            {isSidebarOpen && (
                <div
                    className="fixed inset-0 bg-sumi-950/60 z-30 lg:hidden"
                    onClick={() => setIsSidebarOpen(false)}
                />
            )}

            {/* Main Content */}
            <main className="flex-1 lg:pl-64 min-h-screen">
                <div className="p-8 max-w-6xl mx-auto">
                    {children}
                </div>
            </main>
        </div>
    );
}
