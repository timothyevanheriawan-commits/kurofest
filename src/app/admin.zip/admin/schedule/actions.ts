"use server";

import { createClient } from "@/lib/supabase-server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function upsertEvent(formData: FormData) {
  const supabase = await createClient();

  const id = formData.get("id") as string;
  const isNew = !id || id === "new";

  const eventData = {
    title: formData.get("title") as string,
    title_ja: formData.get("title_ja") as string,
    time_start: formData.get("time_start") as string,
    time_end: formData.get("time_end") as string,
    location: formData.get("location") as string,
    location_ja: formData.get("location_ja") as string,
    type: formData.get("type") as string,
    speaker_id: formData.get("speaker_id") || null,
    description: formData.get("description") as string,
    day: parseInt(formData.get("day") as string),
    is_live: formData.get("is_live") === "on",
    is_featured: formData.get("is_featured") === "on",
    capacity: formData.get("capacity")
      ? parseInt(formData.get("capacity") as string)
      : null,
  };

  let error;
  if (isNew) {
    const { error: insertError } = await supabase
      .from("schedule")
      .insert([eventData]);
    error = insertError;
  } else {
    const { error: updateError } = await supabase
      .from("schedule")
      .update(eventData)
      .eq("id", id);
    error = updateError;
  }

  if (error) {
    console.error("Error upserting event:", error);
    return { error: error.message };
  }

  revalidatePath("/admin/schedule");
  revalidatePath("/schedule");

  redirect("/admin/schedule");
}

export async function deleteEvent(id: string) {
  const supabase = await createClient();

  const { error } = await supabase.from("schedule").delete().eq("id", id);

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/admin/schedule");
  revalidatePath("/schedule");
  return { success: true };
}
