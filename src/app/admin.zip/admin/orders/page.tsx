"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase";
import { Loader2, RefreshCw, Database } from "lucide-react";
import { cn } from "@/lib/utils";

type Order = {
    id: string;
    created_at: string;
    customer_name: string;
    customer_email: string;
    ticket_type: "standard" | "premium" | "vip";
    ticket_price: number;
    status: string;
    confirmation_code: string;
};

export default function AdminOrdersPage() {
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);
    const [seeding, setSeeding] = useState(false);
    const supabase = createClient();

    const fetchOrders = async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from("orders")
            .select("*")
            .order("created_at", { ascending: false });

        if (error) {
            console.error("Error fetching orders:", error);
        } else {
            setOrders(data || []);
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchOrders();
    }, []);

    const seedMockData = async () => {
        setSeeding(true);
        const mockOrders = Array.from({ length: 5 }).map(() => {
            const types = ["standard", "premium", "vip"] as const;
            const type = types[Math.floor(Math.random() * types.length)];
            const price = type === "standard" ? 8500 : type === "premium" ? 15000 : 35000;

            return {
                customer_name: ["Alice Tanaka", "Bob Suzuki", "Charlie Sato", "Diana Ito", "Evan Yamamoto"][Math.floor(Math.random() * 5)],
                customer_email: `user${Math.floor(Math.random() * 1000)}@example.com`,
                ticket_type: type,
                ticket_price: price,
                status: "completed",
                confirmation_code: `KF26-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
                created_at: new Date(Date.now() - Math.floor(Math.random() * 1000000000)).toISOString()
            };
        });

        const { error } = await supabase.from("orders").insert(mockOrders);

        if (error) {
            console.error("Error seeding data:", error);
            alert("Failed to seed data. Check console.");
        } else {
            fetchOrders();
        }
        setSeeding(false);
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        });
    };

    return (
        <div className="space-y-8">
            <header className="flex items-center justify-between">
                <div>
                    <h1 className="font-display text-3xl font-bold text-sumi-950">
                        Orders
                    </h1>
                    <p className="mt-1 font-serif text-sm text-sumi-500">
                        Manage ticket sales
                    </p>
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={seedMockData}
                        disabled={seeding}
                        className={cn(
                            "flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-wider",
                            "border border-sumi-200 text-sumi-600 hover:bg-sumi-100 hover:text-sumi-950 transition-colors",
                            seeding && "opacity-50 cursor-not-allowed"
                        )}
                    >
                        {seeding ? <Loader2 size={14} className="animate-spin" /> : <Database size={14} />}
                        Seed Data
                    </button>
                    <button
                        onClick={fetchOrders}
                        className="flex items-center gap-2 px-4 py-2 bg-sumi-950 text-washi-100 text-xs font-bold uppercase tracking-wider hover:bg-sumi-800 transition-colors"
                    >
                        <RefreshCw size={14} />
                        Refresh
                    </button>
                </div>
            </header>

            <div className="bg-washi-100 border border-sumi-200 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-sumi-50 border-b border-sumi-200">
                            <tr>
                                <th className="px-6 py-4 font-display font-bold text-sumi-950 uppercase tracking-wider text-xs">Order ID / Code</th>
                                <th className="px-6 py-4 font-display font-bold text-sumi-950 uppercase tracking-wider text-xs">Customer</th>
                                <th className="px-6 py-4 font-display font-bold text-sumi-950 uppercase tracking-wider text-xs">Ticket</th>
                                <th className="px-6 py-4 font-display font-bold text-sumi-950 uppercase tracking-wider text-xs">Status</th>
                                <th className="px-6 py-4 font-display font-bold text-sumi-950 uppercase tracking-wider text-xs">Date</th>
                                <th className="px-6 py-4 font-display font-bold text-sumi-950 uppercase tracking-wider text-xs text-right">Amount</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-sumi-100">
                            {loading ? (
                                <tr>
                                    <td colSpan={6} className="px-6 py-12 text-center text-sumi-400">
                                        <div className="flex flex-col items-center gap-2">
                                            <Loader2 className="animate-spin" />
                                            <span>Loading orders...</span>
                                        </div>
                                    </td>
                                </tr>
                            ) : orders.length === 0 ? (
                                <tr>
                                    <td colSpan={6} className="px-6 py-12 text-center text-sumi-400 font-serif italic">
                                        No orders found.
                                    </td>
                                </tr>
                            ) : (
                                orders.map((order) => (
                                    <tr key={order.id} className="hover:bg-sumi-50/50 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="font-mono font-bold text-sumi-950">
                                                {order.confirmation_code}
                                            </div>
                                            <div className="text-[10px] text-sumi-400 font-mono truncate max-w-[100px]" title={order.id}>
                                                {order.id}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="font-medium text-sumi-900">{order.customer_name}</div>
                                            <div className="text-xs text-sumi-500">{order.customer_email}</div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={cn(
                                                "inline-flex items-center px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide border",
                                                order.ticket_type === 'vip' ? "bg-purple-100 text-purple-700 border-purple-200" :
                                                    order.ticket_type === 'premium' ? "bg-amber-100 text-amber-800 border-amber-200" :
                                                        "bg-slate-100 text-slate-700 border-slate-200"
                                            )}>
                                                {order.ticket_type}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                <span className="w-1.5 h-1.5 rounded-full bg-green-600" />
                                                Paid
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-sumi-600 font-mono text-xs">
                                            {formatDate(order.created_at)}
                                        </td>
                                        <td className="px-6 py-4 text-right font-mono font-bold text-sumi-950">
                                            ¥{order.ticket_price.toLocaleString()}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
