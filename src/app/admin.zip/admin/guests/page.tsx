import { createClient } from "@/lib/supabase-server";
import { Plus, Edit, Trash2, Search, User, ExternalLink } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default async function GuestsAdminPage() {
    const supabase = await createClient();

    const { data: guests } = await supabase
        .from("guests")
        .select("*")
        .order("name", { ascending: true });

    return (
        <div className="space-y-8">
            <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                    <h1 className="font-display text-4xl font-black tracking-tight uppercase text-sumi-950">
                        Guests
                    </h1>
                    <p className="mt-2 font-serif text-lg text-sumi-400">ゲスト管理</p>
                </div>

                <Link
                    href="/admin/guests/new"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-shu-600 text-washi-100 text-xs font-bold uppercase tracking-widest hover:bg-shu-500 transition-colors shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
                >
                    <Plus size={16} />
                    Add New Guest
                </Link>
            </header>

            {/* Toolbar */}
            <div className="flex bg-white border-2 border-sumi-950 p-4">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-sumi-300" size={18} />
                    <input
                        type="text"
                        placeholder="Search guests by name or role..."
                        className="w-full pl-10 pr-4 py-2 bg-transparent text-sm focus:outline-none"
                    />
                </div>
            </div>

            {/* Table / Grid */}
            <div className="bg-white border-2 border-sumi-950 overflow-hidden">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="bg-sumi-50 border-b-2 border-sumi-950">
                            <th className="px-6 py-4 text-[10px] font-bold tracking-[0.2em] uppercase text-sumi-400">Guest</th>
                            <th className="px-6 py-4 text-[10px] font-bold tracking-[0.2em] uppercase text-sumi-400">Role</th>
                            <th className="px-6 py-4 text-[10px] font-bold tracking-[0.2em] uppercase text-sumi-400">Status</th>
                            <th className="px-6 py-4 text-[10px] font-bold tracking-[0.2em] uppercase text-sumi-400 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-sumi-100">
                        {guests?.map((guest) => (
                            <tr key={guest.id} className="group hover:bg-washi-50 transition-colors">
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-3">
                                        <div className="relative w-10 h-10 bg-washi-200 border border-sumi-200 overflow-hidden">
                                            {guest.image_url ? (
                                                <Image
                                                    src={guest.image_url}
                                                    alt={guest.name}
                                                    fill
                                                    className="object-cover"
                                                />
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center text-sumi-300">
                                                    <User size={20} className="text-sumi-200" />
                                                </div>
                                            )}
                                        </div>
                                        <div>
                                            <div className="font-bold text-sumi-950">{guest.name}</div>
                                            <div className="text-xs text-sumi-400 font-serif">{guest.name_ja}</div>
                                        </div>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <span className="text-[10px] font-bold tracking-wider uppercase text-sumi-600 bg-sumi-100 px-2 py-1">
                                        {guest.role}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-2">
                                        <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                                        <span className="text-xs text-sumi-500">Live</span>
                                    </div>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <div className="flex items-center justify-end gap-2">
                                        <Link
                                            href={`/admin/guests/${guest.id}`}
                                            className="p-2 text-sumi-400 hover:text-sumi-950 hover:bg-sumi-50 transition-colors"
                                            title="Edit Guest"
                                        >
                                            <Edit size={16} />
                                        </Link>
                                        <button
                                            className="p-2 text-sumi-400 hover:text-shu-600 hover:bg-shu-50 transition-colors"
                                            title="Delete Guest"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                        <Link
                                            href={`/guests/${guest.slug}`}
                                            target="_blank"
                                            className="p-2 text-sumi-400 hover:text-sumi-950 hover:bg-sumi-50 transition-colors"
                                            title="View Public Profile"
                                        >
                                            <ExternalLink size={16} />
                                        </Link>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        {(!guests || guests.length === 0) && (
                            <tr>
                                <td colSpan={4} className="px-6 py-12 text-center text-sumi-400 italic">
                                    No guests found in the database.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
