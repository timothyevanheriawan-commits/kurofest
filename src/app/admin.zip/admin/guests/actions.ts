"use server";

import { createClient } from "@/lib/supabase-server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function upsertGuest(formData: FormData) {
  const supabase = await createClient();

  const id = formData.get("id") as string;
  const isNew = !id || id === "new";

  const guestData = {
    name: formData.get("name") as string,
    name_ja: formData.get("name_ja") as string,
    slug: formData.get("slug") as string,
    role: formData.get("role") as string,
    tagline: formData.get("tagline") as string,
    bio: formData.get("bio") as string,
    image_url: formData.get("image_url") as string,
    span: formData.get("span") as "small" | "large",
    social_links: {
      twitter: formData.get("twitter") as string,
      instagram: formData.get("instagram") as string,
      youtube: formData.get("youtube") as string,
    },
    stats: {
      events: parseInt((formData.get("stats_events") as string) || "0"),
      followers: formData.get("stats_followers") as string,
      awards: parseInt((formData.get("stats_awards") as string) || "0"),
    },
  };

  let error;
  if (isNew) {
    const { error: insertError } = await supabase
      .from("guests")
      .insert([guestData]);
    error = insertError;
  } else {
    const { error: updateError } = await supabase
      .from("guests")
      .update(guestData)
      .eq("id", id);
    error = updateError;
  }

  if (error) {
    console.error("Error upserting guest:", error);
    return { error: error.message };
  }

  revalidatePath("/admin/guests");
  revalidatePath("/guests");
  revalidatePath(`/guests/${guestData.slug}`);

  redirect("/admin/guests");
}

export async function deleteGuest(id: string) {
  const supabase = await createClient();

  const { error } = await supabase.from("guests").delete().eq("id", id);

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/admin/guests");
  revalidatePath("/guests");
  return { success: true };
}
