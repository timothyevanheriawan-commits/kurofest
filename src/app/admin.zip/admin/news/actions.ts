"use server";

import { createClient } from "@/lib/supabase-server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function upsertNews(formData: FormData) {
  const supabase = await createClient();

  const id = formData.get("id") as string;
  const isNew = !id || id === "new";

  const newsData = {
    title: formData.get("title") as string,
    title_ja: formData.get("title_ja") as string,
    slug: formData.get("slug") as string,
    excerpt: formData.get("excerpt") as string,
    content: formData.get("content") as string,
    category: formData.get("category") as string,
    image_url: formData.get("image_url") as string,
    is_featured: formData.get("is_featured") === "on",
    published_at: formData.get("published_at")
      ? new Date(formData.get("published_at") as string).toISOString()
      : new Date().toISOString(),
  };

  let error;
  if (isNew) {
    const { error: insertError } = await supabase
      .from("news")
      .insert([newsData]);
    error = insertError;
  } else {
    const { error: updateError } = await supabase
      .from("news")
      .update(newsData)
      .eq("id", id);
    error = updateError;
  }

  if (error) {
    console.error("Error upserting news:", error);
    return { error: error.message };
  }

  revalidatePath("/admin/news");
  revalidatePath("/news");
  revalidatePath(`/news/${newsData.slug}`);
  revalidatePath("/");

  redirect("/admin/news");
}

export async function deleteNews(id: string) {
  const supabase = await createClient();

  const { error } = await supabase.from("news").delete().eq("id", id);

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/admin/news");
  revalidatePath("/news");
  revalidatePath("/");
  return { success: true };
}
