import { createClient } from "@/lib/supabase-server";
import { upsertNews } from "../actions";
import { ArrowLeft, Save, Trash2, Globe, Eye } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { cn } from "@/lib/utils";

export default async function NewsEditorPage({
    params,
}: {
    params: Promise<{ id: string }>;
}) {
    const { id } = await params;
    const isNew = id === "new";
    let article = null;

    if (!isNew) {
        const supabase = await createClient();
        const { data, error } = await supabase
            .from("news")
            .select("*")
            .eq("id", id)
            .single();

        if (error || !data) {
            notFound();
        }
        article = data;
    }

    const inputClasses = cn(
        "w-full bg-white border-2 border-sumi-200 px-4 py-2 text-sumi-950 font-medium",
        "focus:border-sumi-950 focus:outline-none transition-colors"
    );

    const labelClasses = "block text-[10px] font-bold tracking-[0.2em] uppercase text-sumi-400 mb-2";

    return (
        <div className="space-y-8 pb-24">
            <header className="flex items-center gap-6">
                <Link
                    href="/admin/news"
                    className="p-2 hover:bg-white border-2 border-transparent hover:border-sumi-950 transition-all"
                >
                    <ArrowLeft size={20} />
                </Link>
                <div>
                    <h1 className="font-display text-4xl font-black tracking-tight uppercase text-sumi-950">
                        {isNew ? "New Article" : "Edit Article"}
                    </h1>
                    <p className="mt-1 font-serif text-lg text-sumi-400">
                        {isNew ? "ニュース記事作成" : "記事を編集"}
                    </p>
                </div>
            </header>

            <form action={async (formData) => {
                "use server";
                await upsertNews(formData);
            }} className="grid lg:grid-cols-3 gap-8">
                {!isNew && <input type="hidden" name="id" value={article.id} />}

                <div className="lg:col-span-2 space-y-8">
                    <section className="bg-white border-2 border-sumi-950 p-8 space-y-6">
                        <h2 className="font-display text-sm font-bold uppercase tracking-widest border-b border-sumi-100 pb-2">
                            Article Content
                        </h2>

                        <div className="space-y-6">
                            <div>
                                <label className={labelClasses}>Headline (English)</label>
                                <input
                                    name="title"
                                    defaultValue={article?.title}
                                    className={cn(inputClasses, "text-xl font-black uppercase")}
                                    required
                                />
                            </div>
                            <div>
                                <label className={labelClasses}>Headline (Japanese)</label>
                                <input
                                    name="title_ja"
                                    defaultValue={article?.title_ja}
                                    className={inputClasses}
                                />
                            </div>
                        </div>

                        <div>
                            <label className={labelClasses}>Exceprt / Summary</label>
                            <textarea
                                name="excerpt"
                                defaultValue={article?.excerpt}
                                rows={2}
                                className={cn(inputClasses, "resize-none italic")}
                            />
                        </div>

                        <div>
                            <label className={labelClasses}>Full Content (Markdown)</label>
                            <textarea
                                name="content"
                                defaultValue={article?.content}
                                rows={12}
                                className={cn(inputClasses, "resize-none font-mono text-sm leading-relaxed")}
                            />
                        </div>
                    </section>
                </div>

                <div className="space-y-8">
                    <section className="bg-white border-2 border-sumi-950 p-8 space-y-6">
                        <h2 className="font-display text-sm font-bold uppercase tracking-widest border-b border-sumi-100 pb-2">
                            Publishing Details
                        </h2>

                        <div>
                            <label className={labelClasses}>URL Slug</label>
                            <input
                                name="slug"
                                defaultValue={article?.slug}
                                className={inputClasses}
                                placeholder="news-slug-here"
                                required
                            />
                        </div>

                        <div>
                            <label className={labelClasses}>Category</label>
                            <select name="category" defaultValue={article?.category} className={inputClasses}>
                                <option value="announcement">Announcement</option>
                                <option value="guest">Guest News</option>
                                <option value="schedule">Schedule Update</option>
                                <option value="tickets">Tickets</option>
                            </select>
                        </div>

                        <div>
                            <label className={labelClasses}>Banner Image URL</label>
                            <input
                                name="image_url"
                                defaultValue={article?.image_url}
                                className={inputClasses}
                                placeholder="https://..."
                            />
                        </div>

                        <div>
                            <label className={labelClasses}>Publish Date</label>
                            <input
                                type="datetime-local"
                                name="published_at"
                                defaultValue={article?.published_at ? new Date(article.published_at).toISOString().slice(0, 16) : ""}
                                className={inputClasses}
                            />
                        </div>

                        <div className="pt-4">
                            <label className="flex items-center gap-3 cursor-pointer group">
                                <input
                                    type="checkbox"
                                    name="is_featured"
                                    defaultChecked={article?.is_featured}
                                    className="w-4 h-4 border-2 border-sumi-950 checked:bg-shu-600 transition-all"
                                />
                                <span className="text-xs font-bold uppercase tracking-widest text-sumi-400 group-hover:text-sumi-950">Feature on Homepage</span>
                            </label>
                        </div>
                    </section>

                    <div className="sticky top-24 space-y-4">
                        <button
                            type="submit"
                            className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-sumi-950 text-washi-100 font-bold uppercase tracking-widest hover:bg-shu-600 transition-colors shadow-[8px_8px_0px_0px_rgba(0,0,0,0.2)]"
                        >
                            <Save size={18} />
                            Publish Change
                        </button>

                        {!isNew && (
                            <Link
                                href={`/news/${article.slug}`}
                                target="_blank"
                                className="w-full flex items-center justify-center gap-2 px-6 py-4 border-2 border-sumi-950 text-sumi-950 font-bold uppercase tracking-widest hover:bg-washi-200 transition-colors"
                            >
                                <Eye size={18} />
                                View Public
                            </Link>
                        )}
                    </div>
                </div>
            </form>
        </div>
    );
}
